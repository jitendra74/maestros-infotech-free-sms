Maestros Infotech free sms WordPress plugin
========================

Adds a dashboard widget in WordPress to send a SMS/text message using credentials of your Way2SMS account.


Instructions
-----------------

Hover over the title of the widget, click on configure link on the right side and enter your Way2SMS credentials
