<?php
/*
Plugin Name: Maestros Infotech free sms
Plugin URI: https://github.com/jitendra74/way2sms-wordpress-plugin-by-Maestrosinfotech
Description: Add a page and past shortcode in WordPress to send a SMS/text message using credentials of your Way2SMS account.
Author:jitu
Author Url:http://Maestrosinfotech.com
Version: 1.8
*/
	  	

add_action('admin_menu', 'sms');




function sms(){
	add_options_page("sms", "FREE SMS", 1, "sms", "send");
	global $wpdb;
$charset_collate = $wpdb->get_charset_collate();
$tbnam=$wpdb->prefix."way2sms";
$sql = "CREATE TABLE IF NOT EXISTS $tbnam (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(222) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(222) COLLATE utf8mb4_unicode_ci NOT NULL,
  `limit` int(11) NOT NULL,
  `date` varchar(222) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;";
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );

		;
	function send(){
		global $wpdb;
		
					 
					 
$post_id = wp_insert_post( $post, $wp_error );


		if(isset($_REQUEST['save'])){
			
			$arr=array("user_name"=>$_POST['way2sms_username'],
			"password"=>$_POST['way2sms_password'],"date"=>date('Y-m-d'));
			$sql=$wpdb->insert($wpdb->prefix."way2sms",$arr);
				if($sql>0){
					
					echo "teste";
					
					
					}else{
					
					echo $wpdb->show_errors();
	echo $wpdb->print_error();
					
					}
				
			}
		
	?>
	<style type="text/css">
		#way2sms-wp-plugin .dashboard-widget-control-form label {
			width: 70px;
			display: block;
			float: left;
			padding-top:5px;
		}
	</style>
    <center><h1> Please add way2sms Information to send sms</h1>
     <p>Shortcode :- [way2sms]    copy and past this shortcode in widget ,post and page and start to sent sms on mobile </p>
    <p>add your account of way2sms here </p>
    <form action=""  method="POST">
	<label for="way2sms_username"> Way2sms Username</label>
	<input type="text" name="way2sms_username"   id="way2sms_username" value="<?php echo $way2sms['username']; ?>" maxlength="10" pattern="[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]" />
	<br />
	<label for="way2sms_password">Way2sms Password</label>
	<input type="password" name="way2sms_password"  id="way2sms_password" value="<?php echo $way2sms['password']; ?>" /><br />
	
     
    <input type="submit" class="button-primary" name="save" id="way2sms-submit" value="save" />
   </form>
  <br><br>
  <h1> Way2sms User name and password</h1>
  <table border="1px solid">
  <thead>
 <tr>
 
 <th>No</th>
 <th>User Nmae</th>
 <th>Password</th>
 <th>Today total(<?php echo date('Y-m-d');?>)</th>
 <th>Limit</th>
 
 
 </tr>
  <tbody>
  <?php 
	 
	 
	     //$tbnam=$wpdb->prefix."postmeta";
	     $sql1="SELECT * from `". $wpdb->prefix."way2sms"."`";
		 $postvalue1=$wpdb->get_results($sql1);
		$count=1;
		 foreach( $postvalue1 as  $user)
		 {
			?><tr>
			<td><?php echo $count++; ?></td>
			<td><?php echo $user->user_name; ?></td>
            <td><input type="password" value="<?php echo  $user->password; ?>" readonly="readonly" style="border: none;" /></td>
			<td><?php  echo $user->limit;?></td>
            <td>29sms/per day</td>
			</tr>
            <?php
			 }
		
	?>
    </tbody>
  </table>
 </center>
	<?php
	
	}
} function way2smspag(){
	global $wpdb;
	$sql11="SELECT * from `". $wpdb->prefix."way2sms"."`";
	$postvalue11=$wpdb->get_results($sql11);
	foreach($postvalue11 as $today){
		$day=$today->date;
		if($day !=date('Y-m-d')){
			 $arr = array("limit"=>0,"date"=>date('Y-m-d'));
	        $ses=array("id"=>$today->id);
			$p =  $wpdb->update($wpdb->prefix."way2sms",$arr,$ses);
			}else{}
		}
	  ;
	
	include('way2sms-api.php');
	if(isset($_REQUEST['submit'])){	
	$sql1="SELECT * from `". $wpdb->prefix."way2sms"."` WHERE `limit` !=29";
	$postvalue1=$wpdb->get_results($sql1);
	$user=$postvalue1[0];
$_REQUEST['uid']=$user->user_name;
$_REQUEST['pwd']=$user->password;

if (isset($_REQUEST['uid']) && isset($_REQUEST['pwd']) && isset($_REQUEST['way2sms_recipient']) && isset($_REQUEST['way2sms_message'])) {
    $res = sendWay2SMS($_REQUEST['uid'], $_REQUEST['pwd'], $_REQUEST['way2sms_recipient'], $_REQUEST['way2sms_message']);
   
	if (is_array($res)){
	 $arr = array("limit"=>$user->limit+1);
	 $ses=array("id"=>$user->id);
	 $p =  $wpdb->update($wpdb->prefix."way2sms",$arr,$ses);
        echo $res[0]['result'] ? '<h1>Message to '.$_REQUEST['way2sms_recipient'].' was sent successfully!</h1>': 'false';
		
	}else{
        echo $res;
    exit;
	}
} 
	}
?>
<style type="text/css">
			#way2sms-wp-plugin input[type="text"], #way2sms-wp-plugin textarea {
				margin-bottom:5px;
				width:99%;
			}
			#way2sms-wp-plugin label {
				margin-bottom:5px;
				display:inline-block;
			}
			#way2sms-wp-plugin em {
				display:block;
			}
			#way2sms-wp-plugin #message {
				background-color:lightYellow;
				padding:5px 5px 1px;
				border:solid 1px #E6DB55;
				border-radius:5px;
				-moz-border-radius:5px;
				-webkit-border-radius:5px;
				-khtml-border-radius:5px;
				margin-bottom:10px;
			}
		</style>
		<form action="" method="POST">
			<label for="way2sms_recipient">Recipient's mobile no</label>
			<br />
			<input type="text" name="way2sms_recipient" id="way2sms_recipient" width="500" />
			<em>(Separate multiple nos with comma)</em>
			<br />
			<label for="way2sms_message">Message</label><br />
			<textarea name="way2sms_message" id="way2sms_message" rows="10" cols="60"></textarea>
			<br />
			<input type="submit" class="button-primary" name="submit" id="way2sms-submit" value="Send SMS" />
		</form>



<?php
		
		
		}
		add_shortcode('sms_way2sms', 'send');